require 'test_helper'

class Users::OmniauthCallbacksHelperTest < ActionView::TestCase
end
