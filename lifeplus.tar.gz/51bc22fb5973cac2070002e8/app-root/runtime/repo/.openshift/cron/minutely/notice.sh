#!/bin/bash

curl https://lifeplus-24contest.rhcloud.com/messages/notice
